#include "SDL.h"
#include "Camera.h"
#include "Vertex.h"
#include "WorldViewProjection.h"
#include "PerspectiveProjection.h"
#include "ProcessVertex.h"
#include "Object.h"
#include "ScanLine.h"
#include "LazyFooTimer.h"
#include <iostream>
#include <sstream>
#include <string>

const int screenWidth = 1366;
const int screenHeight = 768;
const double nearPlane = 1;
const double farPlane = 1000;
const double fieldOfView = 65;
const double halfScreenWidth = screenWidth / 2;
const double halfScreenHeight = screenHeight / 2;
const double quarterScreenHeight = screenHeight / 4;
const int framesPerSecond = 1000;

int main(int argc, char* args[])
{
	SDL_Init(SDL_INIT_EVERYTHING);
	SDL_ShowCursor(0);
	SDL_Surface* screen;
	screen = SDL_SetVideoMode(screenWidth, screenHeight, 32, SDL_FULLSCREEN);
	bool running = true;
	SDL_Event event;

	//Next three lines lazyFoo Code
	Timer fps;
	Timer update;
	int frame = 0;

	long int startTicks = 0; 

	double cameraXCoord = 0;
	double cameraYCoord = 0;
	double cameraZCoord = 0;

	double cameraXAngleUPDOWN = 0.5;
	double cameraYAngleLEFTRIGHT = 0.5;

	double mouseX = 0;
	double mouseY = 0;

	bool testMouse = true;
	bool testKeys = true;

	bool renderSecondCam = false;

	Uint8 *keystates = SDL_GetKeyState(NULL);

	Camera cam(10, 0, 0, 0, 0, 1);
	cam.CreateCamMatrix();
	cam.calculateCameraDeterminant();
	cam.calculateAdjointMatrix();
	cam.calculateInverseCameraMatrix();

	Camera camTwo(-10, 0, 0, 0, 0, 1);
	camTwo.CreateCamMatrix();
	camTwo.calculateCameraDeterminant();
	camTwo.calculateAdjointMatrix();
	camTwo.calculateInverseCameraMatrix();

	PerspectiveProj perspProj(nearPlane, farPlane, screenWidth, screenHeight, fieldOfView);
	perspProj.createPerspectiveProjMatrix();

	PerspectiveProj perspProjTwo(nearPlane, farPlane, screenWidth, screenHeight / 2, fieldOfView);
	perspProjTwo.createPerspectiveProjMatrix();

	WVP worldViewProj;

	Object cubeFloor;

	for (double x = 0; x < 1000; x += 10){
		for (double z = 0; z < 1000; z += 10){
			cubeFloor.addVertex(x, -50, z, 1);
		}
	}

	Object cubeCeil;

	for (double x = 0; x < 1000; x += 10){
		for (double z = 0; z < 1000; z += 10){
			cubeCeil.addVertex(x, 50, z, 1);
		}
	}

	Object camSquare;
	for (double x = 0; x < 1; x += 0.1){
		for (double z = 0; z < 1; z += 0.1){
			camSquare.addVertex(x, 0, z, 1);
			camSquare.addVertex(x, 1, z, 1);
		}
	}
	for (double z = 0; z < 1; z += 0.1){
		for (double y = 0; y < 1; y += 0.1){
			camSquare.addVertex(0, y, z, 1);
			camSquare.addVertex(1, y, z, 1);
		}
	}

	for (double x = 0; x < 1; x += 0.1){
		for (double y = 0; y < 1; y += 0.1){
			camSquare.addVertex(x, y, 0, 1);
			camSquare.addVertex(x, y, 1, 1);
		}
	}
	camSquare.setColor(255, 0, 0);

	Object camSquareTwo;
	for (double x = 0; x < 1; x += 0.1){
		for (double z = 0; z < 1; z += 0.1){
			camSquareTwo.addVertex(x, 0, z, 1);
			camSquareTwo.addVertex(x, 1, z, 1);
		}
	}
	for (double z = 0; z < 1; z += 0.1){
		for (double y = 0; y < 1; y += 0.1){
			camSquareTwo.addVertex(0, y, z, 1);
			camSquareTwo.addVertex(1, y, z, 1);
		}
	}

	for (double x = 0; x < 1; x += 0.1){
		for (double y = 0; y < 1; y += 0.1){
			camSquareTwo.addVertex(x, y, 0, 1);
			camSquareTwo.addVertex(x, y, 1, 1);
		}
	}
	camSquareTwo.setColor(0, 255, 0);

	SDL_WarpMouse(halfScreenWidth, halfScreenHeight);

	//LazyFoo Code next two lines
	fps.start();
	update.start();

	while (running){
		SDL_FillRect(screen, &screen->clip_rect, SDL_MapRGB(screen->format, 10, 10, 10));
		startTicks = SDL_GetTicks();

		SDL_WarpMouse(halfScreenWidth, halfScreenHeight);

		camSquare.translate(cam.getxOrigin(), cam.getyOrigin(), cam.getzOrigin());
		camSquareTwo.translate(camTwo.getxOrigin(), camTwo.getyOrigin(), camTwo.getzOrigin());

		if (renderSecondCam == false){

			worldViewProj.multiplyWorldViewProjection(cubeFloor, cam, perspProj);
			worldViewProj.multiplyVertexByWVP(cubeFloor);
			processVerticiesf(cubeFloor, halfScreenWidth, halfScreenHeight, screen, false);

			worldViewProj.multiplyWorldViewProjection(cubeCeil, cam, perspProj);
			worldViewProj.multiplyVertexByWVP(cubeCeil);
			processVerticiesf(cubeCeil, halfScreenWidth, halfScreenHeight, screen, false);
		}

		if (renderSecondCam){

			worldViewProj.multiplyWorldViewProjection(camSquareTwo, cam, perspProjTwo);
			worldViewProj.multiplyVertexByWVP(camSquareTwo);
			processVerticiesf(camSquareTwo, halfScreenWidth, quarterScreenHeight, screen, false);

			worldViewProj.multiplyWorldViewProjection(cubeFloor, cam, perspProjTwo);
			worldViewProj.multiplyVertexByWVP(cubeFloor);
			processVerticiesf(cubeFloor, halfScreenWidth, quarterScreenHeight, screen, false);

			worldViewProj.multiplyWorldViewProjection(cubeCeil, cam, perspProjTwo);
			worldViewProj.multiplyVertexByWVP(cubeCeil);
			processVerticiesf(cubeCeil, halfScreenWidth, quarterScreenHeight, screen, false);

			//Render second camera scene

			worldViewProj.multiplyWorldViewProjection(camSquare, camTwo, perspProjTwo);
			worldViewProj.multiplyVertexByWVP(camSquare);
			processVerticiesf(camSquare, halfScreenWidth, quarterScreenHeight, screen, true);

			worldViewProj.multiplyWorldViewProjection(cubeFloor, camTwo, perspProjTwo);
			worldViewProj.multiplyVertexByWVP(cubeFloor);
			processVerticiesf(cubeFloor, halfScreenWidth, quarterScreenHeight, screen, true);

			worldViewProj.multiplyWorldViewProjection(cubeCeil, camTwo, perspProjTwo);
			worldViewProj.multiplyVertexByWVP(cubeCeil);
			processVerticiesf(cubeCeil, halfScreenWidth, quarterScreenHeight, screen, true);

			if (keystates[SDLK_l]){
				camTwo.rotateYAxis(1);
				camTwo.rotateXAxis(0);
				camTwo.multiplyRotationMatrix();
				camTwo.CreateCamMatrix();
				camTwo.calculateCameraDeterminant();
				camTwo.calculateAdjointMatrix();
				camTwo.calculateInverseCameraMatrix();
			}

			if (keystates[SDLK_j]){
				camTwo.rotateYAxis(-1);
				camTwo.rotateXAxis(0);
				camTwo.multiplyRotationMatrix();
				camTwo.CreateCamMatrix();
				camTwo.calculateCameraDeterminant();
				camTwo.calculateAdjointMatrix();
				camTwo.calculateInverseCameraMatrix();
			}

			if (keystates[SDLK_i]){
				camTwo.rotateXAxis(-1);
				camTwo.rotateYAxis(0);
				camTwo.multiplyRotationMatrix();
				camTwo.CreateCamMatrix();
				camTwo.calculateCameraDeterminant();
				camTwo.calculateAdjointMatrix();
				camTwo.calculateInverseCameraMatrix();
			}

			if (keystates[SDLK_k]){
				camTwo.rotateXAxis(1);
				camTwo.rotateYAxis(0);
				camTwo.multiplyRotationMatrix();
				camTwo.CreateCamMatrix();
				camTwo.calculateCameraDeterminant();
				camTwo.calculateAdjointMatrix();
				camTwo.calculateInverseCameraMatrix();
			}

			//Calculate second cam rotation
			if (keystates[SDLK_d]){
				camTwo.moveCameraRight();
				camTwo.CreateCamMatrix();
				camTwo.calculateCameraDeterminant();
				camTwo.calculateAdjointMatrix();
				camTwo.calculateInverseCameraMatrix();
			}

			if (keystates[SDLK_a]){
				camTwo.moveCameraLeft();
				camTwo.CreateCamMatrix();
				camTwo.calculateCameraDeterminant();
				camTwo.calculateAdjointMatrix();
				camTwo.calculateInverseCameraMatrix();
			}

			if (keystates[SDLK_w]){
				camTwo.moveCameraForward();
				camTwo.CreateCamMatrix();
				camTwo.calculateCameraDeterminant();
				camTwo.calculateAdjointMatrix();
				camTwo.calculateInverseCameraMatrix();
			}

			if (keystates[SDLK_s]){
				camTwo.moveCameraBack();
				camTwo.CreateCamMatrix();
				camTwo.calculateCameraDeterminant();
				camTwo.calculateAdjointMatrix();
				camTwo.calculateInverseCameraMatrix();
			}
		}

		while (SDL_PollEvent(&event)){

			if (event.type == SDL_QUIT){
				running = false;
				break;
			}

			if (keystates[SDLK_ESCAPE]){
				running = false;
				break;
			}
		}

		testKeys = true;

		if (event.type == SDL_MOUSEMOTION){
			if (keystates[SDLK_RIGHT]){
				cam.moveCameraRight();
				testKeys = false;
			}

			if (keystates[SDLK_LEFT]){
				cam.moveCameraLeft();
				testKeys = false;
			}

			if (keystates[SDLK_UP]){
				cam.moveCameraForward();
				testKeys = false;
			}

			if (keystates[SDLK_DOWN]){
				cam.moveCameraBack();
				testKeys = false;
			}

			mouseX = event.motion.x;
			mouseY = event.motion.y;

			mouseX = mouseX - halfScreenWidth;
			mouseY = mouseY - halfScreenHeight;

			mouseX /= 5.0;
			mouseY /= 5.0;	
			
			cam.rotateXAxis(mouseY);
			cam.rotateYAxis(mouseX);
			cam.multiplyRotationMatrix();
			cam.CreateCamMatrix();
			cam.calculateCameraDeterminant();
			cam.calculateAdjointMatrix();
			cam.calculateInverseCameraMatrix();
		}

		if (testKeys){
			if (keystates[SDLK_RIGHT]){
				cam.moveCameraRight();
				cam.CreateCamMatrix();
				cam.calculateCameraDeterminant();
				cam.calculateAdjointMatrix();
				cam.calculateInverseCameraMatrix();
			}

			if (keystates[SDLK_LEFT]){
				cam.moveCameraLeft();
				cam.CreateCamMatrix();
				cam.calculateCameraDeterminant();
				cam.calculateAdjointMatrix();
				cam.calculateInverseCameraMatrix();
			}

			if (keystates[SDLK_UP]){
				cam.moveCameraForward();
				cam.CreateCamMatrix();
				cam.calculateCameraDeterminant();
				cam.calculateAdjointMatrix();
				cam.calculateInverseCameraMatrix();
			}

			if (keystates[SDLK_DOWN]){
				cam.moveCameraBack();
				cam.CreateCamMatrix();
				cam.calculateCameraDeterminant();
				cam.calculateAdjointMatrix();
				cam.calculateInverseCameraMatrix();
			}
		}
		
		SDL_Flip(screen);
		frame++;
		
		
		
		
		
		
		if (update.get_ticks() > 1000)
		{
			cout << "FPS: " << frame / (fps.get_ticks() / 1000.f) << endl;
			update.start();
		}
		if ((SDL_GetTicks() - startTicks) < 1000 / framesPerSecond)
			SDL_Delay((1000 / framesPerSecond) - (SDL_GetTicks() - startTicks));
	}
	return 0;
}
