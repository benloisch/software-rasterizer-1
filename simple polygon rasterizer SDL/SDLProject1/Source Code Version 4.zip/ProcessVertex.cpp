#include "Camera.h"
#include "PerspectiveProjection.h"
#include "ProcessVertex.h"
#include "Vertex.h"
#include "WorldViewProjection.h"
#include "Object.h"
#include "ScanLine.h"
#include <iostream>
#include "SDL.h"
using namespace std;

bool processVerticiesb = false;

double xReplace = 0;
double yReplace = 0;

void processVerticiesf(Object object, double halfScreenWidth, double halfScreenHeight, SDL_Surface* screen, bool renderSecondCam, bool scanLine){
	if (renderSecondCam == false){
		if (scanLine == false){
			for (unsigned int atX = 0; atX < object.objVerticies.size(); atX++){
				double zDepth = object.objVerticies.at(atX).getZPrime();
				if (object.objVerticies.at(atX).getXPrime() < 1 && object.objVerticies.at(atX).getXPrime() > -1 && object.objVerticies.at(atX).getYPrime() < 1 && object.objVerticies.at(atX).getYPrime() > -1 && zDepth > 0 && zDepth < 1){
					if (object.objVerticies.at(atX).getXPrime() < 0)
						xReplace = (halfScreenWidth + ((object.objVerticies.at(atX).getXPrime()) * halfScreenWidth));
					else
						xReplace = (halfScreenWidth + (object.objVerticies.at(atX).getXPrime() * halfScreenWidth));

					if (object.objVerticies.at(atX).getYPrime() > 0)
						yReplace = (halfScreenHeight - ((object.objVerticies.at(atX).getYPrime()) * halfScreenHeight));
					else
						yReplace = (halfScreenHeight - ((object.objVerticies.at(atX).getYPrime()) * halfScreenHeight));

					placePixel(screen, xReplace, yReplace, object.returnRed(), object.returnGreen(), object.returnBlue());
				}
			}
		}
	}
	
	if (renderSecondCam){
		if (scanLine == false){
			for (unsigned int atX = 0; atX < object.objVerticies.size(); atX++){
				double zDepth = object.objVerticies.at(atX).getZPrime();
				if (object.objVerticies.at(atX).getXPrime() < 1 && object.objVerticies.at(atX).getXPrime() > -1 && object.objVerticies.at(atX).getYPrime() < 1 && object.objVerticies.at(atX).getYPrime() > -1 && zDepth > 0 && zDepth < 1){
					if (object.objVerticies.at(atX).getXPrime() < 0)
						xReplace = (halfScreenWidth + ((object.objVerticies.at(atX).getXPrime()) * halfScreenWidth));
					else
						xReplace = (halfScreenWidth + (object.objVerticies.at(atX).getXPrime() * halfScreenWidth));

					if (object.objVerticies.at(atX).getYPrime() > 0)
						yReplace = 2 * halfScreenHeight + (halfScreenHeight - ((object.objVerticies.at(atX).getYPrime()) * halfScreenHeight));
					else
						yReplace = 2 * halfScreenHeight + (halfScreenHeight - ((object.objVerticies.at(atX).getYPrime()) * halfScreenHeight));

					placePixel(screen, xReplace, yReplace, object.returnRed(), object.returnGreen(), object.returnBlue());
				}
			}

			for (int x = 0; x < 2 * halfScreenWidth; x++){
				placePixel(screen, x, 2 * halfScreenHeight, 0, 0, 255);
			}
		}
	}

	if (scanLine){
		
	}

	/*
	if (drawLine == true){
		for (unsigned int atX = 0; atX < object.objVerticies.size(); atX += 2){
			for (unsigned int atM = atX; atM < (atX + 2); atM++){
				double zDepth = object.objVerticies.at(atX).getZPrime();
				if (object.objVerticies.at(atX).getXPrime() < 1 && object.objVerticies.at(atX).getXPrime() > -1 && object.objVerticies.at(atX).getYPrime() < 1 && object.objVerticies.at(atX).getYPrime() > -1 && zDepth > 0.0 && zDepth < 1.0)
					processVerticiesb = true;
				else
					processVerticiesb = false;

				if (processVerticiesb){
					if (object.objVerticies.at(atX).getXPrime() < 0){
						xReplace = (halfScreenWidth - ((-1.00 * object.objVerticies.at(atM).getXPrime()) * halfScreenWidth));
						xReplace = round(xReplace);
					}
					else{
						xReplace = (halfScreenWidth + (object.objVerticies.at(atM).getXPrime() * halfScreenWidth));
						xReplace = round(xReplace);
					}

					if (object.objVerticies.at(atX).getYPrime() > 0){
						yReplace = (halfScreenHeight - ((object.objVerticies.at(atM).getYPrime()) * halfScreenHeight));
						yReplace = round(yReplace);
					}
					else{
						yReplace = (halfScreenHeight + ((-1.00 * object.objVerticies.at(atM).getYPrime()) * halfScreenHeight));
						yReplace = round(yReplace);
					}

					placePixel(screen, xReplace, yReplace, 255, 255, 255);
				}

				if (atM == atX){
					lineStartX = xReplace;
					lineStartY = yReplace;
				}
			
				if (processVerticiesb){
					if (atM == atX + 1){
						double lineEndX = xReplace;
						double lineEndY = yReplace;
						double slope = (lineEndY - lineStartY) / (lineEndX - lineStartX);
						//fill in the line
						double currentY = lineStartY + 0.5 + (0.5 * slope);
						
						for (int currentX = lineStartX + 1; currentX != lineEndX; currentX++){
							placePixel(screen, currentX, floor(currentY), 255, 255, 255);
							double newY = currentY + slope;
							if (floor(newY) != floor(currentY)){
								placePixel(screen, currentX, floor(newY), 255, 255, 255);
							}
							currentY = newY;
						}
					}
				}
			}
		}
	}
	*/
}

void placePixel(SDL_Surface* screen, int x, int y, int r, int g, int b){
	Uint32* pixels = (Uint32*)screen->pixels;
	Uint32* pixel = pixels + y * screen->pitch / 4 + x;
	*pixel = SDL_MapRGB(screen->format, r, g, b);
}




