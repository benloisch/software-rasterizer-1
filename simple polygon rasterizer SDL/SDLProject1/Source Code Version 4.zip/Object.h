#ifndef OBJECT_H
#define OBJECT_H

#include "PerspectiveProjection.h"
#include "Vertex.h"
#include "WorldViewProjection.h"
#include <iostream>
#include <vector>

using namespace std;

class Object
{
private:
	double objXCoord;
	double objYCoord;
	double objZCoord;
	double translateMatrix[4][4];
	int colorR;
	int colorG;
	int colorB;
public:
	//Public vector to let worldviewprojection.h get access too
	vector <Vertex> objVerticies;

	Object(){
		colorR = 255;
		colorG = 255;
		colorB = 255;
		for (int x = 0; x < 4; x++){
			for (int y = 0; y < 4; y++){
				translateMatrix[x][y] = 0;
				if (x == y)
					translateMatrix[x][y] = 1;
			}
		}
	}

	void addVertex(double x, double y, double z, double w){
		objVerticies.push_back(Vertex(x, y, z, w));
	}

	void translate(double x, double y, double z){
		translateMatrix[3][0] = x;
		translateMatrix[3][1] = y;
		translateMatrix[3][2] = z;
	}

	void displayObjectMatrixToConsole()
	{
		cout << "ObjectTranslateMatrix" << endl;
		for (int i = 0; i < 4; i++)
		{
			cout << "[";
			for (int j = 0; j < 4; j++)
			{
				cout << translateMatrix[i][j] << ", ";
			}
			cout << "]" << endl;
		}
	}

	double getElement(int element){
		if (element == 11)
			return translateMatrix[0][0];
		else if (element == 12)
			return translateMatrix[0][1];
		else if (element == 13)
			return translateMatrix[0][2];
		else if (element == 14)
			return translateMatrix[0][3];
		else if (element == 21)
			return translateMatrix[1][0];
		else if (element == 22)
			return translateMatrix[1][1];
		else if (element == 23)
			return translateMatrix[1][2];
		else if (element == 24)
			return translateMatrix[1][3];
		else if (element == 31)
			return translateMatrix[2][0];
		else if (element == 32)
			return translateMatrix[2][1];
		else if (element == 33)
			return translateMatrix[2][2];
		else if (element == 34)
			return translateMatrix[2][3];
		else if (element == 41)
			return translateMatrix[3][0];
		else if (element == 42)
			return translateMatrix[3][1];
		else if (element == 43)
			return translateMatrix[3][2];
		else if (element == 44)
			return translateMatrix[3][3];
		else
			return 0;
	}

	int returnRed(){
		return colorR;
	}

	int returnGreen(){
		return colorG;
	}

	int returnBlue(){
		return colorB;
	}

	void setColor(int r, int g, int b){
		colorR = r;
		colorG = g;
		colorB = b;
	}
};

#endif