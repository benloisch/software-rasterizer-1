#ifndef SCANLINE_H
#define SCANLINE_H

#include "Camera.h"
#include "PerspectiveProjection.h"
#include "ProcessVertex.h"
#include "Vertex.h"
#include "WorldViewProjection.h"
#include "Object.h"
#include "ScanLine.h"
#include <iostream>
#include "SDL.h"

class ScanLine{
private:
	bool processTriangle;

public:
	ScanLine(){
		processTriangle = false;
	}

	void setProcessTriangle(bool set){
		processTriangle = set;
	}

	bool getProcessTriangle(){
		return processTriangle;
	}

	void checkBackFaceCull(Object objectFace){
		
	}
};


#endif